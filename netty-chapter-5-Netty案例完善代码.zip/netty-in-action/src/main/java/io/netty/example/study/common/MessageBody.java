package io.netty.example.study.common;

public abstract class MessageBody {
}
