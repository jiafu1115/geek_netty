package io.netty.example.study.common;

public abstract class Operation extends MessageBody {

    public abstract OperationResult execute();

}
