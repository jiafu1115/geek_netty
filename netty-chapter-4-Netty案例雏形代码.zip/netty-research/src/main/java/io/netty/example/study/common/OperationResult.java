package io.netty.example.study.common;

import lombok.Data;

@Data
public abstract class OperationResult extends MessageBody{

}
